import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms'; // Importa FormsModule


@Component({
  selector: 'app-tablas',
  standalone: true,
  imports: [CommonModule, HttpClientModule,FormsModule],
  templateUrl: './tablas.component.html',
  styleUrls: ['./tablas.component.css'],
})
export class TablasComponent implements OnInit {
  products: any[] = []; // Almacena los productos obtenidos
  currentPage: number = 1; // Página actual
  itemsPerPage: number = 10; // Productos por página
  selectedProduct: any = null; // Producto seleccionado para el modal
  editableProduct: any = {}; // Producto que se edita en el modal
  productToDelete: any = null;
  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.fetchProducts();
  }

  // Consume la API para obtener los productos
  fetchProducts(): void {
    this.http.get<any>('https://dummyjson.com/products').subscribe((response) => {
      this.products = response.products;
    });
  }

  // Maneja la paginación
  get paginatedProducts(): any[] {
    const start = (this.currentPage - 1) * this.itemsPerPage;
    return this.products.slice(start, start + this.itemsPerPage);
  }

  // Cambia la página
  changePage(page: number): void {
    this.currentPage = page;
  }

  openModal(product: any) {
    this.selectedProduct = product;
  }

  openEditModal(product: any) {
    this.editableProduct = { ...product }; // Copia los datos del producto
  }

  saveChanges() {
    const index = this.products.findIndex(
      (p) => p.id === this.editableProduct.id
    );
    if (index !== -1) {
      this.products[index] = { ...this.editableProduct }; // Actualiza solo el estado local
    }
  }

  // Calcula el número total de páginas
  get totalPages(): number[] {
    const total = Math.ceil(this.products.length / this.itemsPerPage);
    return Array.from({ length: total }, (_, index) => index + 1);
  }

  nextPage() {
    this.currentPage++;
  }

  prevPage() {
    if (this.currentPage > 1) this.currentPage--;
  }
  openDeleteModal(product: any) {
    this.productToDelete = product;
  }
  
  deleteProduct() {
    this.products = this.products.filter((p) => p.id !== this.productToDelete.id);
    
    this.productToDelete = null;
  }
}


