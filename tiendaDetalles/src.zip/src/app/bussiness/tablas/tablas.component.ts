import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-tablas',
  standalone: true,
  imports: [CommonModule,  HttpClientModule ],
  templateUrl: './tablas.component.html',
  styleUrls: ['./tablas.component.css']
})
export class TablasComponent implements OnInit {
  products: any[] = []; // Almacena los productos obtenidos
  currentPage: number = 1; // Página actual
  itemsPerPage: number = 10; // Productos por página
  selectedProduct: any = null; // Producto seleccionado para el modal

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.fetchProducts();
  }

  // Consume la API para obtener los productos
  fetchProducts(): void {
    this.http.get<any>('https://dummyjson.com/products').subscribe(response => {
      this.products = response.products;
    });
  }

  // Maneja la paginación
  get paginatedProducts(): any[] {
    const start = (this.currentPage - 1) * this.itemsPerPage;
    return this.products.slice(start, start + this.itemsPerPage);
  }

  // Cambia la página
  changePage(page: number): void {
    this.currentPage = page;
  }

  //selectedProduct: any = null;



openModal(product: any) {
  this.selectedProduct = product;
  const modal = document.getElementById('productModal');
  if (modal) modal.style.display = 'block';
}

closeModal() {
  const modal = document.getElementById('productModal');
  if (modal) modal.style.display = 'none';
}

  

  // Calcula el número total de páginas
get totalPages(): number[] {
  const total = Math.ceil(this.products.length / this.itemsPerPage);
  return Array.from({ length: total }, (_, index) => index + 1);
}
nextPage() {
  this.currentPage++;
}

prevPage() {
  if (this.currentPage > 1) this.currentPage--;
}
}

